"""Bounded, read-only creator probe for A/B telemetry and the B treatment gate.

Only public RPC reads are used. The candidate-time result is capped at 350 ms;
no transaction, signature, or private key is ever constructed or submitted.
"""
from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from typing import Any, Optional

import aiohttp

from creator_watch import is_solana_pubkey
from pumpportal_validation import (
    TOKEN_2022_PROGRAM_ID,
    TOKEN_PROGRAM_ID,
    derive_associated_token_address,
)
from telemetry import get_collector


class CreatorOnchainProbe:
    def __init__(
        self,
        session: aiohttp.ClientSession,
        http_rpc_url: str,
        timeout_sec: float = 0.35,
        concurrency: int = 2,
        signature_cache_sec: float = 0.0,
    ) -> None:
        self.session = session
        self.http_rpc_url = http_rpc_url
        # A strict cap prevents a caller from silently turning the gate into a
        # long wait. Signature counts are decision-time data: no cache is used.
        self.timeout_sec = min(0.35, max(0.05, float(timeout_sec)))
        self._sem = asyncio.Semaphore(max(2, int(concurrency)))
        self._tasks: set[asyncio.Task[Any]] = set()
        self._closed = False

    async def _rpc(self, method: str, params: list[Any]) -> dict[str, Any]:
        payload = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
        async with asyncio.timeout(self.timeout_sec):
            async with self._sem:
                async with self.session.post(
                    self.http_rpc_url,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=self.timeout_sec),
                ) as response:
                    if response.status != 200:
                        raise RuntimeError(f'rpc_http_{response.status}')
                    data = await response.json()
        if not isinstance(data, dict) or data.get('error'):
            raise RuntimeError('rpc_error_response')
        return data

    async def _signatures(
        self, creator: str,
    ) -> tuple[Optional[dict[str, Any]], Optional[str]]:
        try:
            data = await self._rpc('getSignaturesForAddress', [creator, {'limit': 25}])
            rows = (data.get('result') or [])
            if not isinstance(rows, list):
                raise RuntimeError('signature_result_not_list')
            block_times: list[int] = []
            for row in rows:
                if not isinstance(row, dict):
                    continue
                try:
                    block_time = int(row.get('blockTime'))
                    if block_time >= 0:
                        block_times.append(block_time)
                except (TypeError, ValueError, OverflowError):
                    pass
            return {
                # This is a capped page count, not a wallet-age proof.
                'count': min(len(rows), 25),
                'oldest_block_time': min(block_times) if block_times else None,
                'observed_at_utc': _utc_iso(time.time()),
                'observed_at_epoch': time.time(),
            }, None
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            return None, type(exc).__name__

    async def _creator_token_accounts(
        self, creator: str, mint: str,
    ) -> tuple[Optional[dict[str, Any]], Optional[str]]:
        expected_atas = {
            address for address in (
                derive_associated_token_address(creator, mint, TOKEN_PROGRAM_ID),
                derive_associated_token_address(creator, mint, TOKEN_2022_PROGRAM_ID),
            ) if address
        }
        if not expected_atas:
            return None, 'ata_derivation_failed'
        try:
            data = await self._rpc(
                'getTokenAccountsByOwner',
                [creator, {'mint': mint}, {
                    'encoding': 'jsonParsed', 'commitment': 'processed',
                }],
            )
            rows = ((data.get('result') or {}).get('value'))
            if not isinstance(rows, list):
                raise RuntimeError('token_accounts_result_not_list')
            ata_rows: list[tuple[int, int, str]] = []
            all_balance_raw = 0
            all_decimals: Optional[int] = None
            for row in rows:
                if not isinstance(row, dict):
                    continue
                pubkey = row.get('pubkey')
                account = row.get('account') or {}
                program_owner = account.get('owner') if isinstance(account, dict) else None
                parsed = ((account.get('data') or {}).get('parsed') or {}) if isinstance(account, dict) else {}
                info = parsed.get('info') if isinstance(parsed, dict) else None
                if (
                    program_owner not in {TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID}
                    or not isinstance(info, dict)
                    or info.get('owner') != creator
                    or info.get('mint') != mint
                ):
                    continue
                token_amount = info.get('tokenAmount') or {}
                try:
                    amount = int(token_amount.get('amount') or 0)
                    decimals = int(token_amount.get('decimals'))
                except (TypeError, ValueError, OverflowError):
                    continue
                if amount < 0 or decimals < 0 or decimals > 18:
                    continue
                all_balance_raw += amount
                all_decimals = decimals if all_decimals is None else all_decimals
                if pubkey in expected_atas:
                    ata_rows.append((amount, decimals, str(pubkey)))

            ata_exists = bool(ata_rows)
            ata_balance_raw = sum(item[0] for item in ata_rows)
            decimals = ata_rows[0][1] if ata_rows else all_decimals
            divisor = 10 ** decimals if decimals is not None else 1
            return {
                # `ata_exists` is true only when the returned account address
                # matches the locally derived SPL or Token-2022 associated ATA.
                'ata_exists': ata_exists,
                'ata': ata_rows[0][2] if ata_rows else None,
                'balance_raw': str(ata_balance_raw),
                'balance_ui': ata_balance_raw / divisor if decimals is not None else 0.0,
                'total_owner_mint_balance_raw': str(all_balance_raw),
                'decimals': decimals,
                'accounts_count': len(rows),
            }, None
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            return None, type(exc).__name__

    async def probe(self, coin: Any) -> dict[str, Any]:
        """Return one candidate-time probe result; either RPC may fail closed."""
        if self._closed:
            return {
                'status': 'unavailable', 'errors': ['probe_closed'],
                'signature_count': None, 'ata_exists': None,
                'token_balance_raw': None, 'creator_gate_passed': False,
            }
        task = asyncio.create_task(self._probe(coin), name=f'creator-probe-{str(getattr(coin, "mint", ""))[:7]}')
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return await task

    def schedule(self, coin: Any) -> Optional[asyncio.Task[Any]]:
        """Compatibility helper for telemetry-only callers; does not gate them."""
        if self._closed:
            return None
        task = asyncio.create_task(self.probe(coin), name=f'creator-probe-scheduled-{str(getattr(coin, "mint", ""))[:7]}')
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return task

    async def _probe(self, coin: Any) -> dict[str, Any]:
        mint = str(getattr(coin, 'mint', '') or '')
        creator = str(getattr(coin, 'program_creator', '') or '')
        packet = getattr(coin, 'packet', {})
        packet = packet if isinstance(packet, dict) else {}
        tx_payer = getattr(coin, 'tx_payer', None)
        event_actor = packet.get('pumpportal_event_actor')
        signature = str(getattr(coin, 'signature', '') or '')
        started_epoch = time.time()
        started_mono = time.monotonic()

        if not is_solana_pubkey(creator) or not is_solana_pubkey(mint):
            return self._record_result(
                coin, {
                    'status': 'unavailable', 'errors': ['creator_or_mint_invalid'],
                    'signature_count': None, 'oldest_block_time': None,
                    'ata_exists': None, 'token_balance_raw': None,
                    'token_balance_ui': None, 'creator_gate_passed': False,
                    'latency_ms': round((time.monotonic() - started_mono) * 1000.0, 2),
                }, started_epoch, time.time(), tx_payer, event_actor, signature,
            )

        signature_task = asyncio.create_task(self._signatures(creator))
        accounts_task = asyncio.create_task(self._creator_token_accounts(creator, mint))
        try:
            sig_result, accounts_result = await asyncio.gather(
                signature_task, accounts_task, return_exceptions=True,
            )
        except asyncio.CancelledError:
            for child in (signature_task, accounts_task):
                if not child.done():
                    child.cancel()
            await asyncio.gather(signature_task, accounts_task, return_exceptions=True)
            raise

        if isinstance(sig_result, BaseException):
            sig_data, sig_error = None, type(sig_result).__name__
        else:
            sig_data, sig_error = sig_result
        if isinstance(accounts_result, BaseException):
            token_data, token_error = None, type(accounts_result).__name__
        else:
            token_data, token_error = accounts_result

        errors = [error for error in (sig_error, token_error) if error]
        signature_count = sig_data.get('count') if sig_data else None
        ata_exists = token_data.get('ata_exists') if token_data else None
        balance_raw = token_data.get('balance_raw') if token_data else None
        try:
            positive_ata_balance = int(balance_raw or 0) > 0
        except (TypeError, ValueError, OverflowError):
            positive_ata_balance = False
        gate_passed = signature_count == 25 and ata_exists is True and positive_ata_balance
        if not errors:
            status = 'ok'
        elif sig_data is not None or token_data is not None:
            status = 'partial'
        else:
            status = 'unavailable'
        observed_epoch = time.time()
        values = {
            'status': status,
            'program_creator': creator,
            'tx_payer': tx_payer if is_solana_pubkey(tx_payer) else None,
            'tx_payer_source': packet.get('tx_payer_source'),
            'pumpportal_event_actor': event_actor if is_solana_pubkey(event_actor) else None,
            'transaction_signature': signature or None,
            'first_signer_probe_status': 'not_requested',
            'probe_started_at_utc': _utc_iso(started_epoch),
            'observed_at_utc': _utc_iso(observed_epoch),
            'latency_ms': round((time.monotonic() - started_mono) * 1000.0, 2),
            'getSignaturesForAddress_limit': 25,
            'signature_count': signature_count,
            'creator_signature_count_0_25': signature_count,
            'oldest_block_time': sig_data.get('oldest_block_time') if sig_data else None,
            'creator_signature_oldest_block_time': sig_data.get('oldest_block_time') if sig_data else None,
            'signature_data_observed_at_utc': sig_data.get('observed_at_utc') if sig_data else None,
            'ata_exists': ata_exists,
            'creator_token_ata_exists': ata_exists,
            'creator_token_ata': token_data.get('ata') if token_data else None,
            'token_balance_raw': balance_raw,
            'creator_token_balance_raw': balance_raw,
            'creator_token_balance_ui': token_data.get('balance_ui') if token_data else None,
            'creator_total_owner_mint_balance_raw': token_data.get('total_owner_mint_balance_raw') if token_data else None,
            'creator_token_decimals': token_data.get('decimals') if token_data else None,
            'creator_token_accounts_count': token_data.get('accounts_count') if token_data else None,
            'creator_gate_passed': gate_passed,
            'creator_gate_reason': 'creator_gate_not_met' if not gate_passed else 'creator_gate_met',
            'errors': errors,
            'paper_only_read_only_rpc': True,
        }
        return self._record_result(
            coin, values, started_epoch, observed_epoch, tx_payer, event_actor, signature,
            signature_count=signature_count,
            oldest_block_time=values['oldest_block_time'],
            ata_exists=ata_exists,
            token_balance_raw=balance_raw,
            token_balance_ui=token_data.get('balance_ui') if token_data else None,
        )

    def _record_result(
        self, coin: Any, values: dict[str, Any], started_epoch: float,
        observed_epoch: float, tx_payer: Any, event_actor: Any, signature: str,
        signature_count: Optional[int] = None,
        oldest_block_time: Optional[int] = None,
        ata_exists: Optional[bool] = None,
        token_balance_raw: Optional[str] = None,
        token_balance_ui: Optional[float] = None,
    ) -> dict[str, Any]:
        mint = str(getattr(coin, 'mint', '') or '')
        source = str(getattr(coin, 'source', 'Pump.fun'))
        if signature_count is None:
            signature_count = values.get('signature_count')
        if oldest_block_time is None:
            oldest_block_time = values.get('oldest_block_time')
        if ata_exists is None:
            ata_exists = values.get('ata_exists')
        if token_balance_raw is None:
            token_balance_raw = values.get('token_balance_raw')
        if token_balance_ui is None:
            token_balance_ui = values.get('creator_token_balance_ui')
        collector = get_collector()
        if collector is not None:
            try:
                collector.record_creator_probe(
                    mint=mint, source=source,
                    program_creator=str(getattr(coin, 'program_creator', '') or '') or None,
                    tx_payer=tx_payer if is_solana_pubkey(tx_payer) else None,
                    status=str(values.get('status') or 'unavailable'),
                    values=values,
                    signature_count=signature_count,
                    oldest_block_time=oldest_block_time,
                    ata_exists=ata_exists,
                    token_balance_raw=token_balance_raw,
                    token_balance_ui=token_balance_ui,
                    latency_ms=values.get('latency_ms'),
                    observed_at_utc=values.get('observed_at_utc') or _utc_iso(observed_epoch),
                    error_type=','.join(values.get('errors') or []) or None,
                )
            except Exception:
                pass
        return values

    async def close(self) -> None:
        self._closed = True
        pending = [task for task in self._tasks if not task.done()]
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)


def _utc_iso(epoch: float) -> str:
    return datetime.fromtimestamp(float(epoch), timezone.utc).isoformat(timespec='milliseconds')
