# Solana Sniper — paper A/B workspace

## Scope and safety

- This workspace is for **A/B paper trading only** (`portfolio_scope=ab_only`). It is not configured for signing, submitting, or spending real funds.
- RPC access is read-only. Never put Helius/API credentials in source files, manifests, logs, or archives.
- Do not start a new run unless explicitly requested.

## Active code and tests

- Launcher: `bash run_rocket2_ab_paper.sh`
- Entry point: `main_ab.py`
- A/B portfolio and exact-quote logic: `portfolio_ab.py`, `pump_curve_quote.py`, `price.py`
- Telemetry: `telemetry.py`
- Read-only monitor: `live_ab_dashboard.py`
- Tests: `tests/` (the last full suite run passed 68 tests before workspace cleanup).
- Dependencies: `requirements.txt`; a virtual environment is not currently present and can be rebuilt if needed.

The A/B source modules, tests, `wallet.json`, and `sniper.db` are retained in this workspace. Older entrypoints, launch scripts, and historical docs were archived separately.

## Last run status

Run `20261021T174318Z-28258057` was stopped by request after about 38m 36s of its planned 60 minutes. Its manifest was not finalized, and no final `ab_summary.json` or final RPC metrics were written. The stop-time snapshot is provisional, not a validated result; no synthetic exits were added. The runner and dashboard remain stopped.

## Archived data in private Dropbox

- Full run history, telemetry, local checkpoints, and the previous `/home/user/archive` contents:
  `/Solana Sniper Paper/workspace-archive-20261021T183125Z/solana-sniper-data-archive-20261021T183125Z.zip`
- Older non-A/B entrypoints, launch/sync scripts, and historical docs:
  `/Solana Sniper Paper/workspace-archive-20261021T183125Z/solana-sniper-legacy-code-20261021T183125Z.zip`
- Stop-state report/config/package remain in:
  `/Solana Sniper Paper/rocket2-ab-paper-20261021T174318Z-28258057-stop-state-20261021T182313Z/`

The Dropbox folders are private; no public share link was created.
