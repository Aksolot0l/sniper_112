from __future__ import annotations

import asyncio
import time
import unittest
from types import SimpleNamespace

from creator_probe import CreatorOnchainProbe
from pumpportal_validation import (
    TOKEN_2022_PROGRAM_ID,
    TOKEN_PROGRAM_ID,
    b58decode,
    derive_associated_token_address,
)

CREATOR = '2MRQDEBy1XfwvgwL8GbxXsD5wPq4gncn1YpsUKkosUFk'
MINT = '32CfGsZjrkHJukZuh97YN7t2eh8EmcuLkGuEzEYPBeRm'


class FakeResponse:
    status = 200

    def __init__(self, value, session=None):
        self.value = value
        self.session = session

    async def __aenter__(self):
        if self.session is not None:
            self.session.active += 1
            self.session.max_active = max(self.session.max_active, self.session.active)
            await asyncio.sleep(self.session.delay_sec)
        return self

    async def __aexit__(self, exc_type, exc, traceback):
        if self.session is not None:
            self.session.active -= 1
        return None

    async def json(self):
        return self.value


class FakeSession:
    def __init__(self, *, ata_pubkey=None, delay_sec=0.0):
        self.calls = []
        self.ata_pubkey = ata_pubkey or derive_associated_token_address(CREATOR, MINT, TOKEN_PROGRAM_ID)
        self.delay_sec = delay_sec
        self.active = 0
        self.max_active = 0

    def post(self, _url, **kwargs):
        payload = kwargs['json']
        self.calls.append(payload)
        if payload['method'] == 'getSignaturesForAddress':
            result = [
                {'signature': f'public-sig-{i}', 'blockTime': 1_720_000_100 - i}
                for i in range(25)
            ]
        elif payload['method'] == 'getTokenAccountsByOwner':
            result = {'value': [{
                'pubkey': self.ata_pubkey,
                'account': {
                    'owner': TOKEN_PROGRAM_ID,
                    'data': {'parsed': {'info': {
                        'owner': CREATOR,
                        'mint': MINT,
                        'tokenAmount': {'amount': '1234567', 'decimals': 6},
                    }}},
                },
            }]}
        else:
            raise AssertionError(f'unexpected RPC method {payload["method"]}')
        return FakeResponse({'jsonrpc': '2.0', 'id': payload['id'], 'result': result}, self)


class CreatorProbeTests(unittest.IsolatedAsyncioTestCase):
    async def test_signature_count_is_uncached_capped_page_stat(self) -> None:
        session = FakeSession()
        probe = CreatorOnchainProbe(session, 'https://rpc.example.invalid')
        result, error = await probe._signatures(CREATOR)
        self.assertIsNone(error)
        self.assertIsNotNone(result)
        self.assertEqual(result['count'], 25)
        self.assertEqual(result['oldest_block_time'], 1_720_000_076)
        second, error = await probe._signatures(CREATOR)
        self.assertIsNone(error)
        self.assertEqual(second['count'], 25)
        self.assertEqual(len(session.calls), 2)
        self.assertEqual({call['method'] for call in session.calls}, {'getSignaturesForAddress'})

    async def test_probe_runs_signature_and_ata_reads_in_parallel_without_gettransaction(self) -> None:
        session = FakeSession(delay_sec=0.04)
        probe = CreatorOnchainProbe(session, 'https://rpc.example.invalid', timeout_sec=0.35)
        coin = SimpleNamespace(
            mint=MINT, program_creator=CREATOR, tx_payer=None,
            source='Pump.fun', packet={}, signature='public-create-signature',
        )
        started = time.monotonic()
        result = await probe.probe(coin)
        elapsed = time.monotonic() - started
        self.assertEqual(result['status'], 'ok')
        self.assertTrue(result['creator_gate_passed'])
        self.assertEqual(result['signature_count'], 25)
        self.assertTrue(result['ata_exists'])
        self.assertEqual(result['token_balance_raw'], '1234567')
        self.assertEqual(session.max_active, 2)
        self.assertLess(elapsed, 0.25)
        self.assertEqual(
            {call['method'] for call in session.calls},
            {'getSignaturesForAddress', 'getTokenAccountsByOwner'},
        )
        self.assertTrue(all(call['method'] != 'getTransaction' for call in session.calls))

    async def test_non_associated_token_account_does_not_satisfy_ata_gate(self) -> None:
        ata = derive_associated_token_address(CREATOR, MINT, TOKEN_PROGRAM_ID)
        ata_2022 = derive_associated_token_address(CREATOR, MINT, TOKEN_2022_PROGRAM_ID)
        self.assertIsNotNone(ata)
        self.assertIsNotNone(ata_2022)
        self.assertEqual(len(b58decode(ata) or b''), 32)
        self.assertEqual(len(b58decode(ata_2022) or b''), 32)
        self.assertNotEqual(ata, ata_2022)

        # The owner has a positive mint balance, but the returned token-account
        # address is deliberately not either locally-derived associated ATA.
        session = FakeSession(ata_pubkey=MINT)
        probe = CreatorOnchainProbe(session, 'https://rpc.example.invalid')
        balance, error = await probe._creator_token_accounts(CREATOR, MINT)
        self.assertIsNone(error)
        self.assertIsNotNone(balance)
        self.assertFalse(balance['ata_exists'])
        self.assertEqual(balance['balance_raw'], '0')
        self.assertEqual(balance['total_owner_mint_balance_raw'], '1234567')

        coin = SimpleNamespace(
            mint=MINT, program_creator=CREATOR, tx_payer=None,
            source='Pump.fun', packet={}, signature='sig',
        )
        result = await probe.probe(coin)
        self.assertFalse(result['creator_gate_passed'])


if __name__ == '__main__':
    unittest.main()
