#!/usr/bin/env bash
set -euo pipefail
set +x

PROJECT='/home/user/solana_sniper'
PYTHON="$PROJECT/.venv/bin/python3"
RUN_ID="${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)-$(od -An -N4 -tx1 /dev/urandom | tr -d '[:space:]')}"
RUN_DIR="$PROJECT/runs/rocket2-ab-paper-$RUN_ID"
LOCK="$PROJECT/runs/rocket2-ab-paper.lock"

cd "$PROJECT"
if [[ ! "$RUN_ID" =~ ^[A-Za-z0-9._-]+$ ]]; then
    echo 'ERROR: RUN_ID may contain only letters, digits, dot, underscore, and hyphen.'
    exit 8
fi
if [[ -z "${HELIUS_API_KEY:-}" ]]; then
    echo 'ERROR: HELIUS_API_KEY is not present in the process environment; no run started.'
    exit 10
fi
if [[ -e "$RUN_DIR" ]]; then
    echo 'ERROR: this RUN_ID already has an archive/state directory; refusing reuse.'
    exit 9
fi
if [[ ! -x "$PYTHON" ]]; then
    echo 'ERROR: project virtualenv missing; refusing unverified system Python.'
    exit 4
fi
if pgrep -af '[p]ython3 -u /home/user/solana_sniper/main_ab.py' >/dev/null; then
    echo 'ERROR: another A/B paper runner is active; refusing a second session.'
    exit 2
fi
mkdir -p "$PROJECT/runs"
exec 9>"$LOCK"
if ! flock -n 9; then
    echo 'ERROR: A/B paper runner lock is already held.'
    exit 3
fi
mkdir -p "$RUN_DIR/exports"

# Enforce the isolated A/B-only paper profile. Secrets remain in inherited
# process environment only; no keyed URL is exported to disk or printed.
unset SOLANA_HTTP_RPC_URL SOLANA_WSS_RPC_URL
export RUN_ID RUN_DIR
export RUN_DURATION_SEC="${RUN_DURATION_SEC:-3600}"
export PAPER_ONLY='1'
export MODE='portfolio'
export SOURCES='pumpfun'
export PORTFOLIO_SCOPE='ab_only'
export PUMP_SOURCE='pumpportal'
export DEPOSIT_RUB='1500'
export MAX_POSITIONS='3'
export MAX_TRADE_RUB='500'
export MAX_HOLD_SEC='90'
export USD_RUB_RATE='90'
export ENTRY_FEE_SOL='0.00008'
export EXIT_FEE_SOL='0.00005'
export PROTOCOL_FEE_PCT='1.25'
export HONEYPOT_CHECK='off'
export ONLY_SOL_PAIRS='on'
export SHADOW_NOTIONAL_RUB='0'
export FILTER_CONCURRENCY='4'
export INDEXER_RETRIES='0'
export INDEXER_RETRY_DELAY_SEC='0.12'
export RPC_BATCH_WINDOW_SEC='0.008'
export CREATOR_RISK_POLICY='warn'
export CREATOR_HISTORY_DIR="$PROJECT/runs"
export CREATOR_BLOCKLIST_PATH="$PROJECT/runs/known_scam_sellers.txt"
export TELEMETRY_RUN_ID="$RUN_ID"
export TELEMETRY_OBSERVATION_OFFSETS_SEC='0,5,10,15,60,120'
export WALLET_PATH="$RUN_DIR/wallet_portfolio_a.json"
export TRADE_LOG="$RUN_DIR/trades.log"
export DB_PATH="$RUN_DIR/sniper.db"
export TELEMETRY_DB_PATH="$RUN_DIR/telemetry.sqlite"
export TELEMETRY_EXPORT_DIR="$RUN_DIR/exports"

"$PYTHON" -m py_compile \
  config.py creator_watch.py creator_probe.py telemetry.py filters.py price.py \
  pumpportal_validation.py pump_curve_quote.py portfolio_ab.py main_ab.py detector.py \
  storage.py models.py sqlite_snapshots.py live_ab_dashboard.py run_overnight_ab_paper.py || exit 5
"$PYTHON" -m unittest discover -s tests -v > "$RUN_DIR/preflight_tests.log" 2>&1 || {
    echo 'ERROR: preflight tests failed; no run started.'
    tail -n 80 "$RUN_DIR/preflight_tests.log"
    exit 6
}
if [[ ! "$RUN_DURATION_SEC" =~ ^[0-9]+$ ]]; then
  echo 'ERROR: RUN_DURATION_SEC must be an integer; no run started.'
  exit 7
fi
if [[ -n "${OVERNIGHT_RUN_DEADLINE_EPOCH:-}" ]]; then
  remaining="$($PYTHON -c 'import os,time; print(max(0,int(float(os.environ["OVERNIGHT_RUN_DEADLINE_EPOCH"])-time.time())))')"
  if (( remaining < 1 )); then
    echo 'ERROR: overnight active deadline has elapsed; no run started.'
    exit 7
  fi
  if (( remaining < RUN_DURATION_SEC )); then
    RUN_DURATION_SEC="$remaining"
  fi
fi
export RUN_DURATION_SEC

"$PYTHON" - <<'PY'
import os
from urllib.parse import urlsplit
from dataclasses import asdict
from config import load_settings
from detector import PUMP_PROGRAM_ID, select_programs
from main_ab import _observation_offsets
from portfolio_ab import PROFILE_A, PROFILE_B
from pump_curve_quote import PUMP_FEE_CONFIG_PDA, PUMP_GLOBAL_PDA
s = load_settings()
assert s.api_key
assert 'helius' in (urlsplit(s.http_rpc_url).hostname or '').lower()
assert s.sources == 'pumpfun' and len(select_programs(s.sources)) == 1
assert PUMP_PROGRAM_ID in select_programs(s.sources)
assert s.deposit_rub == 1500 and s.max_positions == 3 and s.max_trade_rub == 500
assert s.mode == 'portfolio' and s.honeypot_check is False
assert PROFILE_A.initial_balance_rub == PROFILE_B.initial_balance_rub == 1500
assert PROFILE_A.position_size_rub == PROFILE_B.position_size_rub == 500
assert PROFILE_A.max_slots == PROFILE_B.max_slots == 3
assert {k:v for k,v in asdict(PROFILE_A).items() if k not in {'name','require_creator_gate'}} == {k:v for k,v in asdict(PROFILE_B).items() if k not in {'name','require_creator_gate'}}
assert PROFILE_A.require_creator_gate is False and PROFILE_B.require_creator_gate is True
assert PUMP_GLOBAL_PDA and PUMP_FEE_CONFIG_PDA
assert s.entry_fee_sol == 0.00008 and s.exit_fee_sol == 0.00005
assert os.getenv('PAPER_ONLY') == '1'
assert os.getenv('SHADOW_NOTIONAL_RUB') == '0'
assert _observation_offsets() == (0, 5, 10, 15, 60, 120)
assert os.getenv('SOLANA_HTTP_RPC_URL') is None and os.getenv('SOLANA_WSS_RPC_URL') is None
print('A/B preflight OK: Helius host only; read-only; paper-only; one pumpfun source; common entry/exit rules; B creator-gate only; fees and observations configured.')
PY

# Stream logs without echoing environment variables or keyed URLs.
set +e
"$PYTHON" -u main_ab.py 2>&1 | tee -a "$RUN_DIR/run.log"
status=${PIPESTATUS[0]}
set -e
exit "$status"
