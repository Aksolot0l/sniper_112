SOLANA PUMP.FUN — PAPER A/B — ЛОКАЛЬНЫЙ ПРОГОН (2ч30м)
=======================================================

ЧТО ЭТО
  Бумажный (paper-only) двойной портфель A/B на Pump.fun.
  Ни одна транзакция не подписывается и не отправляется. RPC — только чтение.
  Портфель A: вход по живому импульсу.
  Портфель B: тот же вход + creator-guard (идентификация дева, отсев раг-ферм).

ЗАПУСК
  Windows:      двойной клик по START_WINDOWS.bat
  macOS/Linux:  bash START_MAC_LINUX.sh

  Скрипт сам создаст .venv, поставит зависимости и спросит HELIUS_API_KEY
  (ключ живёт только в памяти процесса, в файлы не пишется).

  Проверочный короткий прогон:
      bash START_MAC_LINUX.sh --smoke 150
      START_WINDOWS.bat --smoke 150

  Окно терминала НЕ закрывать: процесс идёт в foreground.
  Остановка — Ctrl+C: бот завершится аккуратно, без синтетических выходов.

ГДЕ СМОТРЕТЬ
  Дашборд открывается сам: http://127.0.0.1:8767/
  Можно открыть файл paper_ab_dashboard.html напрямую (он сам найдёт монитор
  на 127.0.0.1:8767).
  Данные прогона: runs/rocket2-ab-paper-<RUN_ID>/
      wallet_portfolio_a.json / wallet_portfolio_b.json  — состояние портфелей
      ab_summary.json                                    — итоги
      telemetry.sqlite                                   — вся воронка решений
      sniper.db                                          — закрытые сделки
      run.log                                            — лог

ЧТО ПРОВЕРИТЬ ПОСЛЕ ПРОГОНА
  1) В telemetry.sqlite (таблица decisions) стадии portfolio_a_signal и
     portfolio_b_signal: сколько раз сработало live_momentum_entry против
     no_live_momentum / birth_out_of_band / momentum_too_late.
  2) portfolio_b_creator_gate: pass / fail / censored и причины
     (creator_burst_activity = раг-ферма, creator_history_too_short и т.д.).
  3) Сравнить realized_pnl_rub портфелей A и B за один и тот же период.

ОГРАНИЧЕНИЯ
  * Один процесс за раз (лимит Helius RPS). Второй запуск будет отклонён.
  * 3 слота × 500 ₽ на портфель, старт 1500 ₽.
  * фильтр дублей по символу по символу отключён.
